N=int(input("Enter the positive integer: "))

for i in range(1,N + 1):
    if(i != N):
        print("%d^2 + " %i, end = ' ')
s=0
s=(N* (N + 1) * (2 *N + 1)) /N
print ("total number of the sum",s)