
num1=int(input("Enter the first number: "))

num2=int(input("Enter the second number: "))

product = num1*num2

result= (num1+num2) \
    if product > 1000 else product

print(result)

