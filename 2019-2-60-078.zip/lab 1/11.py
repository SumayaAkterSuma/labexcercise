string = input("Given a string: ")
str= string[::2]
print("The even index string are :"+str)