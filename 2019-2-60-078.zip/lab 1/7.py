Given_list = [1, 2, 3, 4, 5, 6, 7, 8, 9]
t=0
for ele in range(0, len(Given_list)):
	t = t + Given_list[ele]
print(" sum of all elements: ",t)

