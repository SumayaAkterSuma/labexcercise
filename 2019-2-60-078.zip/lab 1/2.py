
n=float(input("Enter the input number: "))
area= 3.14*n*n
perameter=3.14*2*n
print("Area of the circle: ",area)
print("Perameter of the circle: ",perameter)