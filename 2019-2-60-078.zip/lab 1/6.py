def f(n):
   if n<=0:
      print("wrong input")

   elif n==1:
      return 0
   elif n==2:
      return 1
   else:
      return f(n-1)+f(n-2)
n=int(input("Enter any positive number: "))
print(n,"th Fibonacci number is ", f(n))