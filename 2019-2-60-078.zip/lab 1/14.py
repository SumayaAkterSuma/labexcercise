def isPalindrome(s):
    return s == s[::-1]

s = input("Enter a string: ")
ans = isPalindrome(s)

if ans:
    print("This is a palindrom number ")
else:
    print("This is not a palindrom number")