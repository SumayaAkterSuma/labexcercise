p = float(input("Enter the principal amount : "))
r = float(input("Enter the rate of interest : "))
t = float(input("Enter the number of years : "))

def compound_interest_078 (p, r, t):
    cominter = p * (pow((1 + r / 100), t))
    return cominter

cominter = compound_interest_078 (p, r, t)

print("Compound interest :",cominter)
