def prime_find_078 (N):
    if N > 1:
        for i in range(2, int(N / 2) + 1):

            if (N % i) == 0:
                print(N, "is not a prime number")
                break

        else:
            print(N, "is a prime number")

    else:
        print(N, "is not a prime number")

N = int(input("Enter any positive number: "))
prime_find_078 (N)