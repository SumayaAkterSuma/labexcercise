
cgpa_greater_than_three_point_five1 = df1[df1['cgpa'] > 3.5]
cgpa_greater_than_three_point_five2 = df1.loc[df1['cgpa'] > 3.5]
cgpa_greater_than_three_point_five3 = df1.query('cgpa > 3.5')

print(cgpa_greater_than_three_point_five1)
print(cgpa_greater_than_three_point_five2)
print(cgpa_greater_than_three_point_five3)
df1.sort_values(by='age',ascending=False)